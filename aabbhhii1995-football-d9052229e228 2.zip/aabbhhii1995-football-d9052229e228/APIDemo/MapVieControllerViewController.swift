//
//  MapVieControllerViewController.swift
//  APIDemo
//
//  Created by Abhishek Bansal on 2019-06-29.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import MapKit
import CoreLocation


class MapVieControllerViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    //MARK: Outlet
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.mapView.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
        
        //let URL = "https://httpbin.org/get"
        let URL = "https://fbase-example-157f9.firebaseio.com/QuarterFinal.json"
        
        Alamofire.request(URL).responseJSON {
            
            response in
            
            // TODO: Put your code in here
            // ------------------------------------------
            // 1. Convert the API response to a JSON object
            
            // -- check for errors
            let apiData = response.result.value
            if (apiData == nil) {
                print("Error when getting API data")
                return
            }
            // -- if no errors, then keep going
            
            //print(apiData)
            
            
            // 2. Parse out the data you need (sunrise / sunset time)
            
            // example2 - parse an array of dictionaries
            
            // 2a. Convert the response to a JSON object
            let jsonResponse = JSON(apiData)
            
            //print(jsonResponse)
            
            // 2b. Get the array out of the JSON object
            var responseArray = jsonResponse.arrayValue
            
            
            
            let item = responseArray[0];
            //print(item)
            
            // 2c. Get the 3rd item in the array
            // item #3 = position 2
            
            //getting Lat - Long for Quarter final
            print("Quarter Final Games")
            let lat0 = 49.498777;
            print(lat0)
            let long0 = 0.169737;
            print(long0)

            let lat2 = 49.498770;
            print(lat2)
            let long2 = 0.169722;
            print(long2)

            let lat3 = 49.338291;
            print(lat3)
            let long3 = 0.157180;
            print(long3)

            let lat4 = -26.106560;
            print(lat4)
            let long4 = 28.230850;
            print(long4)

            
            //getting Stadium Name for Quarter final
           
            let stadium0 = responseArray[0]["Stadium0"].string ;
            print(stadium0)
            
            let stadium1 = responseArray[1]["Stadium1"].string ;
            print(stadium1)

            let stadium2 = responseArray[2]["Stadium2"].string ;
            print(stadium2)

            let stadium3 = responseArray[3]["Stadium3"].string ;
            print(stadium3!)
            
            
            
           
            // setting up the map view
            let xc = CLLocationCoordinate2DMake(46.227638, 2.213749)
            let x0 = CLLocationCoordinate2DMake(lat0, long0)
            let x1 = CLLocationCoordinate2DMake(lat2, long2)
            let x2 = CLLocationCoordinate2DMake(lat3, long3)
            let x3 = CLLocationCoordinate2DMake(lat4, long4)
            
            // pick a zoom level
            let y = MKCoordinateSpan(latitudeDelta: 0.015, longitudeDelta: 0.015)
            
            // set the region property of the mapview
            let z = MKCoordinateRegion(center: x0, span: y)
            self.mapView.setRegion(z, animated: true)
            
            // EXAMPLE 2:  Add a pin to the map
            // ------------------------------------------------
            
            // 1. Create a pin object
            let pin0 = MKPointAnnotation()
            let pin1 = MKPointAnnotation()
            let pin2 = MKPointAnnotation()
            let pin3 = MKPointAnnotation()
            
            // 2. Set the latitude / longitude of the pin
            pin0.coordinate = x0
            pin1.coordinate = x1
            pin2.coordinate = x2
            pin3.coordinate = x3
            
            // 3. OPTIONAL: add a information popup (a "bubble")
            pin0.title = stadium0
            pin1.title = stadium1
            pin2.title = stadium2
            pin3.title = stadium3
            
            // 4. Show the pin on the map
            self.mapView.addAnnotation(pin0)
            self.mapView.addAnnotation(pin1)
            self.mapView.addAnnotation(pin2)
            self.mapView.addAnnotation(pin3)
            
        }

        // Do any additional setup after loading the view.
    }
    
    
    
    //MARK:Button
    
    @IBAction func zoomInButton(_ sender: Any) {
        print("zoom in pressed")
        
        var r = mapView.region
        
        print("Current zoom: \(r.span.latitudeDelta)")
        
        r.span.latitudeDelta = r.span.latitudeDelta / 3
        r.span.longitudeDelta = r.span.longitudeDelta / 3
        print("New zoom: \(r.span.latitudeDelta)")
        print("________________")
    }
    

    @IBAction func zoomOutButton(_ sender: Any) {
        print("zoom out pressed")
        
        var r = mapView.region
        
        print("Current zoom: \(r.span.latitudeDelta)")
        
        r.span.latitudeDelta = r.span.latitudeDelta * 2
        r.span.longitudeDelta = r.span.longitudeDelta * 2
        print("New zoom: \(r.span.latitudeDelta)")
        print("-------")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
